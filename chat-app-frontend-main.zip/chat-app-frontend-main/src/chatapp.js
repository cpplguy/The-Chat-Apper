/* eslint-disable react-hooks/exhaustive-deps */
import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  Fragment,
} from "react";
import { useNavigate, useParams } from "react-router-dom";
import createSocket from "./misc/socket.js";
import AuthContext from "./authcontext.js";
import SideBar from "./sidebar.js";
import Loading from "./misc/loading.js";
import he from "he";
import filterObscenity from "./obscenity.js";
import "./chatapp.css";
import { getRankBadge } from "./rank.js";
const CensorWordsMemo = React.memo(({ text }) => filterObscenity(text));
const ImageMemo = React.memo(({ img }) => (
  <img
    src={img}
    alt="user-image"
    onError={(e) => {
      e.target.onerror = null;
      e.target.src =
        "https://img.freepik.com/free-photo/abstract-luxury-plain-blur-grey-black-gradient-used-as-background-studio-wall-display-your-products_1258-101806.jpg?semt=ais_hybrid&w=740&q=80";
    }}
  />
));
export default function ChatPage() {
  const { isAuth, setBannedToken, setBannedMessage } = useContext(AuthContext);
  const navigate = useNavigate();
  const { roomId = "main" } = useParams();
  const bottomRef = useRef(null);
  const topRef = useRef(null);
  const socketRef = useRef(null);
  const [message, setMessage] = useState("");
  const [messageLength, setMessageLength] = useState(0);
  const [messages, setMessages] = useState([]);
  const [whoAmI, setWhoAmI] = useState("");
  const [messageViewedIndex, setMessageViewedIndex] = useState(null);
  // eslint-disable-next-line
  const [amountOfMessages, setAmountOfMessages] = useState(0);
  const [disabled, setDisabled] = useState(false);
  const [peopleOnline, setPeopleOnline] = useState(0);
  const [usernames, setUsernames] = useState(["No One"]);

  useEffect(() => {
    const handler = (newMessage) => {
      setMessages(newMessage);
      setAmountOfMessages(newMessage.length);
    };
    const handler2 = (users) => {
      if (!isAuth.auth) { navigate("/"); return; }
      setUsernames(users);
    };
    const handler3 = (length) => { setPeopleOnline(length); };
    const connectHandler = () => {
      const socket = socketRef.current;
      socket.emit("join room", roomId || "main");
      socket.emit("request users connected");
    };
    const errorHandler = (err) => {
      console.error("error has happened while connecting. Error : ", err);
      socketCleanUp();
      navigate("/", { replace: true });
    };
    const banHandler = (bannedStatus) => {
      if (bannedStatus.banned) {
        setBannedMessage(bannedStatus.reason || "No reason given");
        setBannedToken(true);
        socketCleanUp();
        navigate("/bannedPage", { replace: true });
      } else if (bannedStatus.error) {
        socketCleanUp();
        navigate("/", { replace: true });
      }
    };
    const mutedHandler = ({ secondsLeft }) => {
      const minutes = Math.floor(secondsLeft / 60);
      const seconds = secondsLeft % 60;
      const timeLeft = minutes > 0 ? `${minutes} minute(s) and ${seconds} second(s)` : `${seconds} second(s)`;
      alert(`🔇 You are muted for ${timeLeft}!`);
    };
    const unmutedHandler = () => {
      alert("🔊 You have been unmuted!");
    };
    const socketCleanUp = () => {
      if (socketRef.current) {
        const socket = socketRef.current;
        socket.off("connect", connectHandler);
        socket.off("chat message", handler);
        socket.off("users connected", handler2);
        socket.off("users online", handler3);
        socket.off("is banned", banHandler);
        socket.off("connect_error", errorHandler);
        socket.off("muted", mutedHandler);
        socket.off("unmuted", unmutedHandler);
        socket.disconnect();
      }
    };
    const init = () => {
      try {
        if (/[^a-z0-9]/.test(roomId)) navigate("/");
        if (/[A-Z]/.test(roomId)) navigate("/chat/" + roomId.toLowerCase());
        setWhoAmI(isAuth.user);
        if (!isAuth.token) throw new Error("No token provided.");
        const socket = createSocket({ auth: isAuth.token });
        socketRef.current = socket;
        socket.on("connect", connectHandler);
        socket.on("users connected", handler2);
        socket.on("chat message", handler);
        socket.on("users online", handler3);
        socket.on("is banned", banHandler);
        socket.on("connect_error", errorHandler);
        socket.on("muted", mutedHandler);
        socket.on("unmuted", unmutedHandler);
        socket.connect();
        console.log("connected to socket server");
      } catch (err) {
        errorHandler(err);
      }
    };
    init();
    return () => socketCleanUp();
  }, [roomId, isAuth?.token]);

  function setDisabledState() {
    setDisabled(true);
    setTimeout(() => { setDisabled(false); }, 3000);
  }
  const sendMessage = (newMessage) => {
    if (!socketRef.current) { console.error("socket not mounted"); }
    socketRef.current.emit("chat message", newMessage, (error) => {
      if (error) navigate("/", { replace: true });
    });
  };
  function sendHandler(e) {
    if (disabled) return;
    e.preventDefault();
    if (message.trim() === "") { alert("Message cannot be empty."); return; }
    const matc = message.match(/image\((.*?)\)/i);
    if (message.length > 100 && !(/:bypass/i.test(message) && message.length < 5000) && !matc) {
      alert("Message cannot exceed character limit.");
      return;
    }
    if (matc) { sendMessage(matc[0]); } else { sendMessage(message); }
    setMessage("");
    setDisabledState();
    setMessageLength(0);
  }
  function deleteMessage(id) {
    if (socketRef.current) socketRef.current.emit("delete message", id);
  }
  useEffect(() => {
    if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  if (peopleOnline === 0) return <Loading />;
  return (
    <>
      <SideBar usernames={usernames} />
      <div id="chat-container">
        <header>
          <h2>
            <em title={roomId}>
              {(roomId.length > 30 ? roomId.slice(0, 30) + "..." : roomId.toLowerCase() !== "main" ? roomId : "Main Chat") || "Main Chat"}{" "}
              Page
            </em>
          </h2>
          <h2 id="people-online" title="Current amount of users online.">
            Users Online: {peopleOnline}
            <span className={`${peopleOnline > 1 ? "green" : "red"} circle`}></span>
          </h2>
          <button
            id="copy-chat-data"
            onClick={() => {
              navigator.clipboard.writeText(
                `{roomId: ${roomId},\n data-format: JSON} \n\n` +
                messages.map((itm) => {
                  itm.text.match(/image\((.*?)\)/i) ? (itm.text = "[Image]") : (itm.text = he.decode(itm.text));
                  const { __v, _id, image, ...rest } = itm;
                  return JSON.stringify(rest, null, 2);
                })
              ).then(() => alert("Chat messages copied to clipboard")).catch((err) => console.error("failed to copy. Error: ", err));
            }}
          >
            Copy Chat Messages
          </button>
        </header>
        <div id="messages-container">
          <p>
            <span ref={topRef} id="top" style={{ border: "1px solid white", zIndex: "10000" }}></span>
            {messages?.length === 0 ? "messages will appear here" : messages.map((msg, idx) => {
              const userMessage = he.decode(msg.text);
              const d = new Date(msg.createdAt);
              const date = d.toLocaleDateString();
              const time = d.toLocaleTimeString();
              const replaced = msg.email.replace(/📱|💻/g, "").trim();
              const who = whoAmI !== replaced;
              const matc = msg.text.match(/image\((.*?)\)/i);
              const isLink = msg.text.match(/link\((.*?)\)/i);
              const hasImage = !!(msg?.image && msg?.image !== "none");
              const linkText = isLink && isLink[1].includes("https") ? isLink[1] : isLink && `https://${isLink[1]}`;
              const censoredMemo = <CensorWordsMemo text={linkText || userMessage} />;
              const anchor = <a href={linkText} target="_blank" rel="noreferrer">{censoredMemo}</a>;
              return (
                <Fragment key={msg._id}>
                  <span className="user-message-container" style={{ display: "flex", flexDirection: "column", alignItems: `${who ? "flex-start" : "flex-end"}`, marginBottom: "0.5vh" }}>
                    <span className="username" title={msg.email}>
                      {who && (
                        <span className="profile-picture" style={msg.color === "rainbow" ? { background: "linear-gradient(45deg, red, orange, yellow, green, blue, indigo, violet)", backgroundSize: "400% 400%", animation: "rainbow 8s infinite" } : { backgroundColor: `${msg.color || "lightgray"}` }}>
                          <ImageMemo img={hasImage ? msg.image : "/icons8-account-48.png"} />
                        </span>
                      )}
                      {who ? msg.email?.length > 21 ? msg.email.slice(0, 10) + "..." + msg.email.slice(msg.email.length - 9, msg.email.length) : msg.email : ""}{" "}
                      {getRankBadge(msg.rank, !who)}{" "}
                      {who && date}{" "}
                      {who && time.slice(0, +time.slice(0, 2) ? 5 : 4) + time.slice(-2).replace(":", "")}
                      <button
                        className={`delete-message ${!who ? "user" : "client"}`}
                        style={{ display: `${who && !isAuth.isAdmin ? "none" : "flex"}` }}
                        onClick={() => deleteMessage(msg._id)}
                      >
                        X
                      </button>
                    </span>
                    <span
                      className={`${!who ? "user message" : "client message"}`}
                      onMouseEnter={() => setMessageViewedIndex(idx)}
                      onMouseLeave={() => setMessageViewedIndex(null)}
                    >
                      {matc ? <ImageMemo img={matc[1]} /> : messageViewedIndex === idx ? (isLink && anchor) || userMessage : isLink ? anchor : censoredMemo}
                    </span>
                  </span>
                  <br />
                </Fragment>
              );
            })}
          </p>
          <div id="bottom" ref={bottomRef} style={{ position: "absolute", bottom: "0" }}></div>
        </div>
        <section id="input-container-container">
          <div id="input-container">
            <div id="char-count-container">
              <p id="char-count" style={{ color: messageLength > 100 ? "red" : "gainsboro" }}>{messageLength}/100</p>
            </div>
            <input
              type="text"
              value={message}
              onChange={(e) => { setMessage(e.target.value); setMessageLength(e.target.value.length); }}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  if ((message.trim() && !disabled && messageLength <= 100) || /:bypass/i.test(message) || message.match(/image\((.*?)\)/i)) {
                    sendHandler(e);
                  }
                }
              }}
              placeholder="Type your message."
            />
            <button disabled={!message.trim()} id="send-message" onClick={(e) => { sendHandler(e); }}>
              <h1>↑</h1>
            </button>
          </div>
        </section>
      </div>
    </>
  );
}
